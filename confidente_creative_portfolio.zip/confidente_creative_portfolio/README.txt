CONFIDENTE CREATIVE PORTFOLIO

Files:
- index.html: website content
- style.css: purple/black responsive styling
- script.js: mobile menu and current year
- assets/profile-portrait.png: portfolio portrait (if included)

To preview: open index.html in a browser.
To publish: upload this folder to a static website host such as Vercel or Netlify.
Replace the sample project cards with your own real work before presenting them as completed projects.

Contact details currently included:
WhatsApp: +250 793 581 450
Email: confidentdivin@gmail.com
Instagram: @i.am.divin.confident
